
import { BrowserRouter, Routes, Route, Form } from 'react-router-dom';
import {New, Discount, Goods, Delivery, Forums, About} from './components/Pages'
import { MainPage2 } from './components/Route';
import './App.css';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainPage2/> } >
        <Route index element={<div>No page is selected.</div> } />
        <Route path="new" element={<New />} />
        <Route path="discount" element={<Discount />} />
        <Route path="goods" element={<Goods />} />
        <Route path="delivery" element={<Delivery />} />
        <Route path="forums" element={<Forums />} />
        <Route path="about" element={<About />} />
      </Route>
      </Routes>
    </BrowserRouter>


  );
}

export default App;