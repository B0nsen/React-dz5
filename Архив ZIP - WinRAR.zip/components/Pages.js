
export  function New(){
    return <h2>Новинки</h2>;
}
export  function Discount(){
    return <h2>Акции</h2>;
}
export  function Goods(){
    return <h2>Товары в наличии</h2>;
}
export  function Delivery(){
    return <h2>Доставка и оплата</h2>;
}
export  function Forums(){
    return <h2>Форумы</h2>;
}
export  function About(){
    return <h2>Про нас</h2>;
}
export function NotFound(){
    return <h2>Ресурс не найден</h2>;
}
