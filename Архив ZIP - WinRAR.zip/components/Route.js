import React, { useEffect } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';

export const MainPage2 = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    console.log('Current location is ', location);
  }, [location]);

  return (
    <>
      <nav>
        <ul>
          <li>
            <button onClick={() => navigate('new', { replace: false })}>
              Новинки
            </button>
          </li>
          <li>
            <button onClick={() => navigate('discount', { replace: false })}>
              Акции
            </button>
          </li>
          <li>
            <button onClick={() => navigate('goods', { replace: false })}>
              Товары в наличии
            </button>
          </li>
          <li>
            <button onClick={() => navigate('delivery', { replace: false })}>
              Доставка и оплата
            </button>
          </li>
          <li>
            <button onClick={() => navigate('forums', { replace: false })}>
              Форумы
            </button>
          </li>
          <li>
            <button onClick={() => navigate('about', { replace: false })}>
              Про нас
            </button>
          </li>
        </ul>
      </nav>
      <hr />
      <Outlet />
    </>
  )
};